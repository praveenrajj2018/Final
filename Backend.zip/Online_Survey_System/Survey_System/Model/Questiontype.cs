﻿namespace Survey_System.Model
{
    public enum QuestionType
    {
        Text,
        MultipleChoice,
       
    }
}

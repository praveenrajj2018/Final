import React from "react";

export default function Icons() {
  const data = [
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/Wallet-Icon.png",
      Tittle: "Employee enagement",
    },
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/015-search.png",
      Tittle: "Event handling",
    },
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/Trolley-Icon.png",
      Tittle: "Collaboration",
    },
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/Security-Icon.png",
      Tittle: "Security",
    },
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/Payments-Icon.png",
      Tittle: "Easy POLL Methods ",
    },
    {
      icon: "https://7oroof.com/tfdemos/optime/wp-content/uploads/2019/03/Call-Center-Icon.png",
      Tittle: "24/7 Hours Support",
    },
  ];

  return (
    <>
      {data.map((_, index) => {
        return (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center justify-center space-y-5 border-[1px] border-gray-200 p-5 ">
              <img src='https://cdn3.f-cdn.com/contestentries/2367858/66294732/65c3d91b1121e_thumb900.jpg' alt="" className="w-10 h-10" />
              <h1 className="font-semibold ">{_.Tittle}</h1>
            </div>
          </React.Fragment>
        );
      })}
    </>
  );
}

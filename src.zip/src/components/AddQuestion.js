import React, { useState } from 'react';
import axios from 'axios';

const AddQuestions = () => {
    const [surveyId, setSurveyId] = useState('');
    const [questions, setQuestions] = useState([{ text: '', options: [''] }]);

    const addQuestion = () => {
        setQuestions([...questions, { text: '', options: [''] }]);
    };

    const addOption = (questionIndex) => {
        const newQuestions = [...questions];
        newQuestions[questionIndex].options.push('');
        setQuestions(newQuestions);
    };

    const removeOption = (questionIndex, optionIndex) => {
        const newQuestions = [...questions];
        newQuestions[questionIndex].options.splice(optionIndex, 1);
        setQuestions(newQuestions);
    };

    const removeQuestion = (questionIndex) => {
        const newQuestions = [...questions];
        newQuestions.splice(questionIndex, 1);
        setQuestions(newQuestions);
    };

    const handleQuestionChange = (event, questionIndex) => {
        const newQuestions = [...questions];
        newQuestions[questionIndex].text = event.target.value;
        setQuestions(newQuestions);
    };

    const handleOptionChange = (event, questionIndex, optionIndex) => {
        const newQuestions = [...questions];
        newQuestions[questionIndex].options[optionIndex] = event.target.value;
        setQuestions(newQuestions);
    };

    const addQuestionsToSurvey = async () => {
        try {
            const response = await axios.post('http://localhost:5004/api/Survey/AddQuestions', {
                SurveyId: surveyId,
                Questions: questions.map(q => ({ Texts: [q.text], Options: q.options }))
            });

            console.log('Success:', response.data);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div class="min-h-screen  flex items-center justify-center" id="imagequestion">
        <div class=" p-20 rounded shadow-xl" id="one">
            <h1 style={{color:"white",paddingBottom:"20"}}><b>Welcome, Create your customized survey and share it to  endones</b></h1><br></br><br></br><h2><b>Survey ID</b></h2>
            <input class="border border-gray-200 p-2 w-full mb-4 rounded" type="text" value={surveyId} onChange={e => setSurveyId(e.target.value)} placeholder="Survey ID" />
            {questions.map((question, questionIndex) => (
                <div key={questionIndex} class="mb-4">
                    <p class="text-gray-700"><b>Question {questionIndex + 1}</b></p>
                    <input class="border border-gray-200 p-2 w-full mb-2 rounded" type="text" value={question.text} onChange={e => handleQuestionChange(e, questionIndex)} placeholder="Question" />
                    {question.options.map((option, optionIndex) => (
                        <div key={optionIndex} class="flex items-center space-x-4">
                            <input class="border border-gray-200 p-2 w-full mb-2 rounded" type="text" value={option} onChange={e => handleOptionChange(e, questionIndex, optionIndex)} placeholder="Option" />
                            <button class="bg-yellow-500 text-white px-1 py-1 rounded hover:bg-red-600" onClick={() => removeOption(questionIndex, optionIndex)}>Remove</button>
                        </div>
                    ))}
                    <div class="flex items-center space-x-4">
                        <button class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600" onClick={() => addOption(questionIndex)}>Add Option</button>
                        <button class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600" onClick={() => removeQuestion(questionIndex)}>Remove Question</button>
                    </div>
                </div>
            ))}
            <button class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 mb-4" onClick={addQuestion}>Add Question</button>
            <button class="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600" onClick={addQuestionsToSurvey}>Submit</button>
        </div>
    </div>
    )
    
}

export default AddQuestions;

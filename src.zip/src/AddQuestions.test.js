import { render, fireEvent, waitFor, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import Enquire from './Enquire';

test('renders Enquire component', () => {
  render(<Enquire />);
  const linkElement = screen.getByText(/Make a Poll Now/i);
  expect(linkElement).toBeInTheDocument();
});

test('form submits correctly', async () => {
  render(<Enquire />);
  
  // Mock the Firebase functions
  jest.mock('../Firebase', () => ({
    collection: jest.fn(() => ({
      addDoc: jest.fn(() => Promise.resolve('Document successfully written!')),
    })),
  }));

  const nameInput = screen.getByLabelText('Name');
  const emailInput = screen.getByLabelText('Email');
  const mobileInput = screen.getByLabelText('Mobile');
  const companyInput = screen.getByLabelText('Company');
  const enquiryInput = screen.getByLabelText('Enquiry');
  const messageInput = screen.getByLabelText('Message');
  const submitButton = screen.getByRole('button', { name: /submit/i });

  // Update form fields
  fireEvent.change(nameInput, { target: { value: 'Test Name' } });
  fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
  fireEvent.change(mobileInput, { target: { value: '1234567890' } });
  fireEvent.change(companyInput, { target: { value: 'Test Company' } });
  fireEvent.change(enquiryInput, { target: { value: 'Test Enquiry' } });
  fireEvent.change(messageInput, { target: { value: 'Test Message' } });

  // Submit form
  fireEvent.click(submitButton);

  // Assert form submission
  await waitFor(() => expect(screen.getByText('Number is verified!')).toBeInTheDocument());
});

﻿using Survey_System.Data;
namespace Survey_System

{
    public class LoginDto

    {
           public string? UserEmail { get; set; }
            public string? Password { get; set; }
        
    }
}

﻿namespace Survey_System
{
    public class DeleteQuestionDto
    {
        public int SurveyId { get; set; }
        public int QuestionId { get; set; }
    }
}

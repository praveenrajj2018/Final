import React, { useEffect, useState } from "react";
import {
  AiOutlineTwitter,
  AiFillLinkedin,
  AiFillFacebook,
  AiOutlineMenu,
  AiOutlineMail,
  AiOutlineShoppingCart,
  AiOutlineWechat,
  AiOutlineArrowRight,
} from "react-icons/ai";
import { Link } from "react-router-dom";
import { DropDown, MobileNavbar } from "./index";
import { useSelector } from "react-redux";
import vvmain from "../images/vvlogo.png";
import whatsapp from "../images/whatsapp-icon.png";
import linkedin from "../images/linkedin.png";
import { doc, getDoc } from "firebase/firestore";
import {Login} from "../Comp1/login.component"
import {Registers} from "../Comp1/signup.component"
import { db } from "../Firebase";
export default function Navbar({ Page }) {
  const [service, setservice] = useState(false);
  const [what, setWhat] = useState(false);
  const [who, setWho] = useState(false);
  const [ScrollY, setScrollY] = useState(false);
  const [toogle, settoogle] = useState(false);
  const [mobilewhat, setmobilewhat] = useState(false);
  const [mobilewho, setmobilewho] = useState(false);
  const [mobileservice, setmobileservice] = useState(false);
  const [nonmobilewhat, setnonmobilewhat] = useState(false);
  const [nonmobilewho, setnonmobilewho] = useState(false);

  const [links, setlinks] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const documentRef = doc(db, "SOCIAL-MEDIA-URL", "LINKS");
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
          setlinks(documentSnapshot.data());
        } else {
          setlinks(null); // Handle the case where the document doesn't exist
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
    window.scrollTo(0, 0);
  }, []);

  const cart = useSelector((state) => state.cart);
  const handleScroll = () => {
    if (window.scrollY > 50) {
      setScrollY(true);
    } else if (window.scrollY === 0) {
      setScrollY(false);
    }
  };
  // console.log(what, who);
  useEffect(() => {
    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
      <nav className="z-50">
        {/* Show Navbar only on Scroll */}
        <div
          className={` ${
            ScrollY
              ? "lg:fixed top-0 left-0 right-0 z-50  bg-white shadow-md ease-in-out duration-500"
              : "hidden"
          } w-screen `}
        >
          <div className=" px-10 lg:px-24 py-3.5 flex justify-between items-center shadow-md  ">
            <div>
              <Link
                to={"/"}
                onClick={() => {
                  window.scrollTo(0, 0);
                }}
              >
                <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdIAAABsCAMAAADpCcO1AAABUFBMVEX///8nJVzgG1EPC1IlI1u1tcESDlO/v84AAEwWE1W4t8ciIFrs7PGZJH5HRnGpqbzk5Ora2uMDAE+0tMTR0dqPjqgAAEocGlf09PUZFlXe3uSTk6uyIW6lpbvXHFcfHVipInR0dJLAH2XSHVrJHmC6IGm9H2fVHFj+9vikI3erInO0IG3iIFnGHmKEg53oz+IAAEVsao2eI3sAAEFVVHw4NmtxcJDKytZiYYdSUHtCQG5/fprfAEYxL2OVDnjHAFfxytq5cqfv3uvTNHKrQ4ulMIOoTZPTpMSaBHLIN3bXss6dNom7PoLKlbzp0+TVMGiyYp6jC2+vB2f4ytbBZJm5Uo386u7kOmnCg7HsgJnoZ4avBmz73+fVkbLsg5zeAD/zscHlTnTeiafpnbPYXofzucjGQn3TUYCxAFvZe57DVov40tvworTJXo/Sp8cAADHNGX2sAAAXZUlEQVR4nO2d7X+bRrbHIVAkBBYISQZEZKI8OolDLFsSCEV2Nm26Th+Sm3TX7TZpd9Pe9GZv29v//92dAWYYYAZQrbTdht+LfBw9MDDfeThz5pwRxzVq1KhRo0aNGjX6A6gVTCMFE/X3vpVG25FmuJHssEH6J5Em8ZGUboP0T6IG6TuXVaUtl9cgfecaH7fZMmQ+nHmavsXyGqQl0uuq9CqoihkSRdeWhPl4a1TfP6RqC6lqxPO1VqeOWuN+2WUqkMZcFWk+3BKB9w/p4DAZ844rntgqBZXRsKx11EEKqUrzVu0Cy/QeIjWSOmxXPHGnvt3S00rerIkUMNgd1i6xRnkN0rysDsfdP7t9+8qVO3cuX75798aNm1evfnjv3vVnz65du7V3gPXhfWAClcyEtZHyvDTdwgM2SFkCHW//o9sAaUoU8Lx+eu3atb29g0upHn8MJmin5EL1kYr24uIP2CBlaDTguL+eEUhvgk4KmV6HfZRg+mTn5BNQjyPmlVKkrlmUq4gkVGN84QdskDIEOun546MjhPRGNO5CpNeySA8+3dnZAZ9nT4MYqTidFLQIloZgplRFY3DRB2yQ0uWDyfEvZ0fZgZeG9DNA9ORzjmsxUaAqFvke7W1L7U9FFzM1LzydNkjpAguYpydH1b30GeykOzuPOM5hGcgVSKF6Mxsztf2LPV+DlC7ohvivk6PqXno7InryF9CvWavKGkg5zkN3dfFu2iClyQJ47p/sVCN9shPr5D67m9ZCynkymk3FC5JokNLUgQuYnWqkB48TpDtgIaMz/A31kFrI8hXtCzqRGqQUjUDdf35SA+mToyPUTT9hdtN6SLkxMoxl5jrGGnTGjuOMO6VWcT2ken/srCYrz9FK7+qCGrX6mtbxf+2WBLxJbzIZjjulrTNFynT4Advo0c7JycnZ2dlzoJcvX7x48fbt26v3rp+enkKggOYDoD2wykFQP93nLDqLmkhH66SbmnR3w2C8bBuCDCUY7ZlWaWGXIPU9pS3Itm2atiy05Umr8MneB0hlY4aFP/VBkdpg3G2324IkgdttL8f4fge9WAOVfq2+hW7STW9yd+3ka8/qo284yLiUtQ9I9XGZPijr/D6hhzl9kehvt29jpidPQTelPndNpNxMSVAsi++p/aUiK3wqV1ZmDNO4CqnqhKZN+jdEU1o7uc/2DCGRwXaicD76VNvI9Q+r383cMLjfUIvLQKORlJ2o9OPkWodRgf7SlMmbBFcLsq1YxbeYLhdkgVR7hT5bdy67fwWMywnUyOalI6uLNEgWp8q88FYnFNyMkwlezpUX1AtWIO3PBYXPSxG6uX2nhYlqqcTXOUUfsnMf6ncFJX/DijCPhjFDjCXkkLaTz8E2pK4kN/d10PLcTClqoUrysr3koy2VHkyynxF44e9XUqYnjzjrQuYRqB8XfS73hjptFyFAmW3aUF+KVA0M+rUUI8h0NB/VsMIONFTRZ0Qz82jWlF6IIszA+Cwk/8v3UgLpYC3Tvi8a5Jy0AdLOuCjP4s6/TDdfDh58wXGfvLxzB0E9+wo0BYYRUHvgZfTSFm8zb9qYFg2CMqS+YTKvZSuZIbaLqEjMfWMHVbwZZApZM2/YtPvVSPUWowmD78zS590AKUUjMG3940G6+fLga9BpX16+g5l+dA6mO8aXayJVw+Q53Fnm9b7Jer7ormcFpiVI+27Ztdw1OTtriJcSMu7YmqOrZTxeHbGkEMXW0IjMQiqPeTYrO3XE1EC64pgC49urS6Recdw3Ly5Dpncg07O/gupijU81kfrIGsjeSN/IWDJwMyfzKEWmbKR9m6xsUXHhRhDxissTBoiFihEFhnHdQWuHTCP0MzfMKyawWclCsNHDQsqXoSJm4Av10sEg10m/Baucu3cvJ0yv3P5on9M7rG/XRIo6KbDEM9VG7NLYhj1brBaB0ibYyEHuQkykfpu4likYyym41rwtp1WjGMRXhqibsho7sud4gxigeuS2kt02wslqtVoalAGfiRTfjS0ZMKJIzrAz0Py2icVbEOikP/6T6KNfnnPczzciptHg+/xh9BmG6iEdoymGN4lOMVpjdqK89gZJjxwMw9TCl3L7eiykKp+2A1tZoDgcfRxI+A2TsJF6ePwTqAPQAFFS5sQE18WWqmjzHg7Za03tPNQKpIo0X417nKW3nKlCLLrsSfIFq49ErEv7GTHX7v6I2/+aIPrgXxz38MYNwDTpqH+PZ1uGaiFt4ZvOTF0zXA9mdumoOrjpima2bBbSCW7MijnJWEKtOeZAbsHjJYpEXcescEUSby/SQtxVxl7sTeXsHFuO1EbL2OS7+A3RLCyUa3iPsoKRgm/IifQ1ePGHmwTT+2WdtBbSFBAvEJfq4/0ZeZm3p328UHCz9gsDaUtARbh8fuWtdxEJZZ2W46PSlSWlqlTciXfTcnw81ihSYXnf4TMdtRSpEGTbo4MvTJkha0cI4jsBn3t9kEam/BMsYN5cvXkTQX3xt3i2ZSlFyvDD6GNZSqczYhmoitiUoDgJdTwoG5l5nIEUm6dul7LaCnCXS+cfa4YnS4r3ZYyn2kn6Ir4lV6EUonZJpmVIhQI2Db+thPkGtilSFTzOT5f29hBUuIA5v3f16lXM9Jzl3U1uBsceOZ1+Xtp4OFuTni/S1MDzq72gjSg+6tpuxuqlI+2jkV3hac9toYlW5FMWfVR+bl0VCTUR0U2bM7aBlTW1jash4RMqQSpPit8l5o38tTdFCqv41h5UDPUALGC+O713DzF98Q14lLKthhSpLRQkyXZ2TUJsgFtL5PWd028V26SZgCU60i4mQPd3drADkKhpNFaLhVpMR2USN7KBRYlh//fE9GHZSKnPq+JJqOD72BCpDmyP7/du3UJM4QLm1fXr9+6hjnqXuQWTaIOgT7DaJ/qbj4Zj2rgHZVGXslSkvV1EjGXYY+dVN30tXccUBkLsAyZG/RH2JjFjV1PDvgSpQPXaeKibmvk+vCFSGCkIt0gjqIDpl/sc99+nKdO3b0ptI24jpPac7O7I4nS7rEsPbQo9KlLkuxPnrAGlhSqbqJcRNoHyOy2YHmk6oRYgGsxRK52f2Ugp+xZQPvqmkq+PzZAOgEnz72vXIqiwoz4ABN9cu3b9OoL6A1fiZYhUH6kUZKoCbaCyRjFwdwgDuZalIbXQkMj2kWGHJFnV6Tom12xx/yXfQLjYnRQM8JgcEykjBsBC9SGKuXc2QgoXMK+iCPuEKVzAPIuRxkwfVnXS2mlOppH1GfTQxMTsWByHXDVk9dCQ4hWHwN45XCX4yEHWF6gWWMqfJ/xNelLnolyyPYnBMJFSJu5YyLTghdwbGyGF2/1wmL2OoIIFzL/24N8J059B1VdEadZCqtjGIrfG6aBhrPsBSy1k9JD9goa0h33ifebFEFKX8CBZqdMv85QatsVJ/olRLa7LahZPiSyk1FUwFB4y2rk3NkIKOunD06hLRkz3/gFm1lt7txDT6/deVXZSAqmIlKEpKq7dDr1CV8RbIaJUtJQToXZLupxoSPFyJOcFJYX9e+QGKXZ2ZGNRcSe1CfdJHxdcWqWsqAaElDlsY3fVbu6NTZBCy+uHKBEmhvoMEPwWrFEjpgDq6XfsbVKsFKlpJ8p4xtbhzCsG/xBPUEPktjkNqUPdUmZcyyWeKJ3ASN/XgLoHg4y1sqmUmP+Zm2usMApnC0hVMNi8gcNrwvTW9xz348EBmFJvRVBPT/erOymBVPPj9HOfCK7nmcFvC/ZudREDEfxLQzrcoHnwmWij1CVODLG4tWWmZvSqXZomi9eXLKQCyxrcBlKYj/gEhnrGUE+fAYKvL11KmX5fsk2aXqXo47WWGJdLCR6LNS1E37AlEv43GlJvI6SkeaLi4d/GU5yKGmnWaJog+6okWomDsUflSJmJXltAChcw370FC5UE6il07sJt06Sj3vof8HRl+d+xaG57Nd37kCdV1sDvijS9jdSt5CCk2YgwjLQ8mb0SKSskcQtIwQDwKkorTZgCgvtfxlH2B5GHECDWqidk6k5ML90ILbqoY02wvSJXSyhHimtDrHGtwwxSH30VjyfYUSlm3cWo3ZTFh3C/K1IYzvvzTcAUQX3IcT+h2AYA9eBrGE1efg0o+uaaL1YxRTXkBnUOdkm7Og0p2jYRw371pXJzCfb3tBPU2M+U647IBnPzcRYZYXS/A1LQSZ++vQGzEGOm/wYLGCKh/wAGII1r7Lky9ktb6YYafYsZYdg0lY2GtJXUl7je7FpQeHsF+VZTxlljHy9iWPFn8a1ULWLeHVIYY/G/d+9GmaUQ6pPzbADSpW9BV6uTss3aAtdSDzbVT91PkNKi7+uURyLV0UMbNRbjOVkhHmejyu6hEL98b0RDtLguW9fh9dRvjhQuYD55cTdmCjsqXMBkogTrLGCgmFENQ+zVFE3KAO6bjO/VLI/uEKx/mBMWhhCvGPGCKO/3Q8FKpQ5BIj74t0YKOun+ZzBlLWH6BLz2mowS/CkKSqohdqDKEG8BKrTcb4Qh7zKvWV5mJwYtcn9NQrKFIgsVuPVnYTdDYfTA7smSQvxKt/27QgrzEb95CUMAY6hvH8IFTBpuf+n1PmdNnWFBxXVySezRCnshFEpgB06SYU+AOuUZqEixfcSKlgE9WWcZBjigQO4TnhOhsH5DvgaxZHhPl2bvAmnZiA/InN+BmaUx1Bs/c5SkGEstaFRcp5YgJV0OxdSTDpps2dsnynw6zDsTqUhHqMLY4corM2AcOYqmALhzizc8KbkyfnUhrXSxvT2kI2wplNg2A/BoXz2/k0AFTJ+yP5uRxs5Roc2JVphGdXbzX9VReE8xgCqRIymuLbTnK3JsoAeqYBvHZDy2L8AjR9v8lGJ+L7GN28M9Qi46FNItN1YjJGOJt4iUYXGRgmc1PHoOj5qLmb74+ccvvsikmN6n6Jy+G14a9KmnAVZmYVMJn9/AOLQMhVgqu+RsS0fakXE4GbV9IByiQFlV4pWo6WE3JS1eGxtSyprKxerWCCfbHKmOs60pYWhI0LsLjw9EUA+gYQR3YE5hINnNGzdevHh55/nz52dnJ1g753QTuDyOt5e22wI4He1wi1QfWw/34nl1hGBqadqUbDciCNykGGoq/vIaN0Ba7ak41tGlZkJOyA2h7SFVsTurGLadfgh000+ex2dCAn0Y+Rbgnhrc94ZI716+DBOc8FkNOzsn/8cI560IzSbSgow8uCE2n6Ti7DRY4w6TGSsrQ7OlIlMV7w2Z1FVwYXNOlKkb/zh+hTfDQl2MlpmrbA9p6jvNZkVmjUd4YEB0KCSE+lm0bNlLkF6lI/2YtU6tirbvpIlBRn4ew11YbAfZJ1WHOAkzZxEzEyhwhdp8joemoDphHaEmZ7ftWR4iK3VzKkL2zGhrbGS3lraINPXayOn6SXcOM9UJg46ewtRRCPVZBinspXcLSOHJR3QffmUCBT5LpRhJ5ae4zfWkh3qXNfLmOImmbk5Mmg7KK2bg4zd1rZtmERkMAyO/lcMKcWsRiWv2eoiO2FB7w3m+o28RqUqkV4Sarur6qLNYy27WOoEHL3x1FkGNO2kGaaGXwrMaGEnD1TkxacKHmA/ZddLuIdryzBtrmuOtZmRgRH5MZicjEl3NFLorB1xruJryxLEKMisgYSBluin7tJZ0rojuOJx6YLG+6MrZSI4tIyUjQBRBDMO1GZ21mXXgwJMXHh1FSJ8VkRZ66ckjpnuwRprTJA1PknJj4gp7mIBcW5Yk2TbJEaxwLDM7ZVgTCC5KfK1MsL/Ndid3M6MmZQWDtBDID4JFlp3NGcZ/bhNpjyxUVFAbzbmxemB6/xye9fnDpepeevIV+AJjLVYnc22RupHEPFMhN41lVcgYLkvs75Qm9mdOQsirRc6molvieZuWxjnZs6qgz1+DlPOoYZiinL1PWOLR0dHjgxxSmnn06TlnscIz6iC1cOYY785zj+SUHNYgUlYkpcdvrEtCJYRFCSirS9xF2bkWcDnNbISiPLO2vxPDZSqQlJwrAy5kzo6eXKrupfC4uRYLWK2UYSKnq+AabPE2o45sm2LNlB6So88kxrXMfDZ5Tg7RD9rlm4qaxGg4Snti1Tkkh3EHJUjB0pk2OOS3FqDz9OPH6Z53AemVBOnJx2WpTvUS+/XUfrDzbiR1YtCgmsaU5pKtOsrKlYq9XjSNoCLCPE12LUnSQQ8TGJRYOKUd/WzKu0EKJq9imWY7Ny1BC/bph2jvBQJ9Ro67oJc+fvwYLWDY8Q3jXRT8XLrvOeBlFOZrFFyDg4kpkXaMKCqyPKX3lfFhclIc4wwqy1kKtpKZGQV+Ub2Z7xn4/qrDczozI5NkKYqu0Y0d4O3kKu0c0t3ktP9dFtIh+uYxo8wlWaYo2tK00Ezr7Ydy3D48k5L57gjnB5dHtfjpDp1XrDN9PFtLsum6rmnbkr3uDlk3h8tj/lyVOph0eUkCljO8ljuf1frNt5GHbo95QDghqxPMTclUYHKBYsryPEAhTfgps/WtJr+kOw1YM3oLV09ZmYId/XqrLIN1POUz1RGdSOWhq9vRqOUsgiBYrIb9uo2NrUFL8xbgWp72q49WrZLua9P5GiicOu+skEKZ/VUAxSqxp7XqaXzRA+kb/VYa1ETaEG3UqFGjRo0aNWrUqFGjRo0aNWrUqFGjRo0aNWrUqFGjRhRZmwdhbOuHcnXnN4qn+BNp7Cqu67JyaWKFxqZXXfyyyadb7OIHZICqM5sFQTBb1ohYGA3f36bg8NFvR5b/ntzGP28+KD+JPKepwcwTGJDJ/trKm7Un3qrG2Ua+8S5/UPuPLYdIS+x1VMdDXcDShr4ex3n68Wud3sDDgY1qH1OzfHQeQmuQ5KEM4kbQ8ntDDwFQx8MRFXXPXKAToEeaOvZQl+15q/5AyvLTdlFRflJUC34gaXRWx4nPefOHrtN/X6GSSB3BnfPHcY3qazk8XMe/9DSLju21wrAdCodxRfUPZzM5/tM/DKftGNU8WPwSnVmxis+vD+ZG6B7G1e23xXCXerrMZM7xSQy2djgX58fxIYatQ6HbXot5pElMaTeY/hL9LsIcxpAG0VNYXWlhRhHtU1lxC9m+74scyZZlKZ4snV2AM4ij/EMPHn4pRX8HUYVbS8BQ5aMo3B4kq0XB4xb8taNB/Hu4XSEJ+vfiX6FYtAHOMP42vHZLpKQq66bGaVLcPDT4a4hOdFiOpYDRWJ8rDKQzeRa/04U3NI0yLXww8apedCXffl/7KJxLhw5Q/LcM/unERzgdw6qbGCTSLswNXEVH5w/NseOsojNFO7vw+/FPzYVhYpQkSKeQoBOR96NWM6P84MiY71m9uKUAYiPYXuB1B8ew5/cFFlJ0TCmBVJ8vvSSC3JffY6Rh7u+WG3W4Y0hukUUKE6m8yJKZ8JCjA6tNM6I/o9E1RCnLCClsBNq8HKnihmHoCtEcGE2V+i7s6v4x/HdgsJCiM9yjuwrifCh9HB7GI3WDlPg7QTqbqpZmygykziE8uy5K8RgcR/ZJPFqjo3yLSDnDUy1Hiksj7dvOoQMsbidOsYmQjiKkVhsWN7EZSJeo9UC21jpCavnQBojOivFRBlPN38/8M8kxV95qtYqmwBipHCHVZ7ZodOPTkYLEPIqQRjlc6rrbGnTjdK5A1HpTO/rSHB2948VmUEAg9demaIYRUp9IArRmcQebRicFabCpjA6juxnvDv2pkDu6SztE4y3KENd2p+NunP+uS8NRX44sNZ2farCRjJSNF2D/8dJmUMuoHjTY8v3kN6msgTYYx7+M4cUT3QLOl+O4I+pdRUxSlNVg7c5iRgtkZI7jPuTBRtCZJp/zNX0aMR/MU6R6XDTnd+FrrWX0UoxRC/mgH2QH0BbKCpxge9aZr53hKrmIGSZLoM7chIXr8/cPKUueAxOhS85EJxPU6qTCTVtwOHzXFWxR/2wENWzb/OFs8xOdmZod8u5h6YkCjd6xemOHmeH6q+Q7TpNO1qhRo0aNGjVq9EfS/wNwi/NBhJ+MRQAAAABJRU5ErkJggg==' alt="pic"  width={140}/>
              </Link>
            </div>

            <div>
              <ul className="flex items-center text-[0.95rem] text-[#121a37] font-[500] space-x-14">
                <Link to={"/"}>
                  <li className="cursor-pointer hover:text-[#ff5e15] transition duration-300 ease-in-out">
                    Products
                  </li>
                </Link>
                <Link to={"/about"}>
                  <li
                    className={`cursor-pointer hover:text-[#ff5e15] transition duration-300 ease-in-out `}
                  >
                    Solutions
                  </li>
                </Link>
                <div>
                  <li
                    onMouseEnter={() => {
                      setmobileservice(!mobileservice);
                    }}
                    onMouseLeave={() => {
                      setmobileservice(false);
                    }}
                    className="cursor-pointer"
                  >
                    Templates
                  </li>
                  <div
                    onMouseEnter={() => setmobileservice(true)}
                    onMouseLeave={() => setmobileservice(false)}
                    className={`${
                      mobileservice ? "flex" : "hidden"
                    } pt-2 absolute cursor-pointer `}
                  >
                    <ul className="text-sm text-[#676767] w-[16vw] font-semibold">
                      <li
                        onMouseEnter={() => {
                          setmobilewhat(true);
                          setmobilewho(false);
                        }}
                        className="bg-white border py-1.5 px-3  hover:text-[#ff5e15] transition ease-in-out duration-300"
                      >
                        POPULAR CATEGORIES
                      </li>
                      <li
                        onMouseEnter={() => {
                          setmobilewho(true);
                          setmobilewhat(false);
                        }}
                      >
                        <li className="bg-white border  py-1.5 px-3 hover:text-[#ff5e15] transition ease-in-out duration-300">
                        POPULAR TEMPLATES
                        </li>
                      </li>
                    </ul>
                    <div
                      onMouseEnter={() => {
                        setWhat(true);
                      }}
                      onMouseLeave={() => {
                        setWhat(false);
                      }}
                      className={`${
                        mobilewhat ? "flex" : "hidden"
                      } bg-white py-2 text-sm text-[#676767] w-[18vw]`}
                    >
                      <DropDown ismobile={false} type={"Whatwedo"} />
                    </div>
                    <div
                      onMouseEnter={() => {
                        setWho(true);
                      }}
                      onMouseLeave={() => {
                        setWho(false);
                      }}
                      className={`${
                        mobilewho ? "flex" : "hidden"
                      } bg-white py-2 text-sm text-[#676767] w-[18vw]`}
                    >
                      <DropDown ismobile={false} type={"WhoweServe"} />
                    </div>
                  </div>
                </div>
                <Link to="/BlogPage">
                  <li className="cursor-pointer hover:text-[#ff5e15]  transition duration-300 ease-in-out">
                    Pricing
                  </li>
                </Link>
                <Link to={"/shop"}>
                  <li
                    className={`hover:text-[#ff5e15] transition duration-300 ease-in-out cursor-pointer ${
                      Page === "Shop" ? "text-[#ff5e15]" : null
                    } `}
                  >
                    Resources
                  </li>
                </Link>
                <Link to={"/career"}>
                  <li className="cursor-pointer hover:text-[#ff5e15]  transition duration-300 ease-in-out">
                    Blogs
                  </li>
                </Link>
                <Link to={"/contact"}>
                  <li className="cursor-pointer hover:text-[#ff5e15]  transition duration-300 ease-in-out">
                    CONTACT US
                  </li>
                </Link>
              </ul>
            </div>
          </div>
        </div>

        {/*Social icons for Mobile */}
        <div className="lg:hidden bg-[#252a2c] w-screen p-2.5 px-5 md:px-12 flex items-center space-x-3">
          <Link to={links?.Twitter}>
            <AiOutlineTwitter size={25} color="white" />
          </Link>
          <Link to={links?.Linkedin}>
            <AiFillLinkedin size={25} color="white" />
          </Link>
          <Link to={links?.Facebook}>
            <AiFillFacebook size={25} color="white" />
          </Link>
        </div>

        {/* Show case bar for Big screens */}
        {/* <div className="hidden lg:block text-white bg-[#121a37] w-screen z-50 p-3.5 px-0">
          <div className="flex items-center justify-between mx-24 gap-x-28">
            <div className="flex items-center space-x-1.5">
              <AiOutlineMail size={25} color="#ff5e15" />
              <h1 className="text-[#d5d5d5]  cursor-pointer">
                Email:{" "}
                <span className="hover:text-[#ff5e15] transition duration-300 ease-in-out">
                  <a href={`mailto:${links?.Email}`}>{links?.Email}</a>
                </span>
              </h1>
            </div>
            <div className="flex items-center space-x-2.5 cursor-pointer">
              <Link to={links?.Linkedin}>
                <img src={linkedin} className="w-28" alt="" />
              </Link>
            </div>
          </div>
        </div> */}
        {/* Main Navbar */}
        <div className="flex items-center justify-between mx-5 mt-5 md:mx-12 lg:mx-24 ">
          <div>
            <Link
              to={"/"}
              onClick={() => {
                window.scrollTo(0, 0);
              }}
            >
              <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdIAAABsCAMAAADpCcO1AAABUFBMVEX///8nJVzgG1EPC1IlI1u1tcESDlO/v84AAEwWE1W4t8ciIFrs7PGZJH5HRnGpqbzk5Ora2uMDAE+0tMTR0dqPjqgAAEocGlf09PUZFlXe3uSTk6uyIW6lpbvXHFcfHVipInR0dJLAH2XSHVrJHmC6IGm9H2fVHFj+9vikI3erInO0IG3iIFnGHmKEg53oz+IAAEVsao2eI3sAAEFVVHw4NmtxcJDKytZiYYdSUHtCQG5/fprfAEYxL2OVDnjHAFfxytq5cqfv3uvTNHKrQ4ulMIOoTZPTpMSaBHLIN3bXss6dNom7PoLKlbzp0+TVMGiyYp6jC2+vB2f4ytbBZJm5Uo386u7kOmnCg7HsgJnoZ4avBmz73+fVkbLsg5zeAD/zscHlTnTeiafpnbPYXofzucjGQn3TUYCxAFvZe57DVov40tvworTJXo/Sp8cAADHNGX2sAAAXZUlEQVR4nO2d7X+bRrbHIVAkBBYISQZEZKI8OolDLFsSCEV2Nm26Th+Sm3TX7TZpd9Pe9GZv29v//92dAWYYYAZQrbTdht+LfBw9MDDfeThz5pwRxzVq1KhRo0aNGjX6A6gVTCMFE/X3vpVG25FmuJHssEH6J5Em8ZGUboP0T6IG6TuXVaUtl9cgfecaH7fZMmQ+nHmavsXyGqQl0uuq9CqoihkSRdeWhPl4a1TfP6RqC6lqxPO1VqeOWuN+2WUqkMZcFWk+3BKB9w/p4DAZ844rntgqBZXRsKx11EEKqUrzVu0Cy/QeIjWSOmxXPHGnvt3S00rerIkUMNgd1i6xRnkN0rysDsfdP7t9+8qVO3cuX75798aNm1evfnjv3vVnz65du7V3gPXhfWAClcyEtZHyvDTdwgM2SFkCHW//o9sAaUoU8Lx+eu3atb29g0upHn8MJmin5EL1kYr24uIP2CBlaDTguL+eEUhvgk4KmV6HfZRg+mTn5BNQjyPmlVKkrlmUq4gkVGN84QdskDIEOun546MjhPRGNO5CpNeySA8+3dnZAZ9nT4MYqTidFLQIloZgplRFY3DRB2yQ0uWDyfEvZ0fZgZeG9DNA9ORzjmsxUaAqFvke7W1L7U9FFzM1LzydNkjpAguYpydH1b30GeykOzuPOM5hGcgVSKF6Mxsztf2LPV+DlC7ohvivk6PqXno7InryF9CvWavKGkg5zkN3dfFu2iClyQJ47p/sVCN9shPr5D67m9ZCynkymk3FC5JokNLUgQuYnWqkB48TpDtgIaMz/A31kFrI8hXtCzqRGqQUjUDdf35SA+mToyPUTT9hdtN6SLkxMoxl5jrGGnTGjuOMO6VWcT2ken/srCYrz9FK7+qCGrX6mtbxf+2WBLxJbzIZjjulrTNFynT4Advo0c7JycnZ2dlzoJcvX7x48fbt26v3rp+enkKggOYDoD2wykFQP93nLDqLmkhH66SbmnR3w2C8bBuCDCUY7ZlWaWGXIPU9pS3Itm2atiy05Umr8MneB0hlY4aFP/VBkdpg3G2324IkgdttL8f4fge9WAOVfq2+hW7STW9yd+3ka8/qo284yLiUtQ9I9XGZPijr/D6hhzl9kehvt29jpidPQTelPndNpNxMSVAsi++p/aUiK3wqV1ZmDNO4CqnqhKZN+jdEU1o7uc/2DCGRwXaicD76VNvI9Q+r383cMLjfUIvLQKORlJ2o9OPkWodRgf7SlMmbBFcLsq1YxbeYLhdkgVR7hT5bdy67fwWMywnUyOalI6uLNEgWp8q88FYnFNyMkwlezpUX1AtWIO3PBYXPSxG6uX2nhYlqqcTXOUUfsnMf6ncFJX/DijCPhjFDjCXkkLaTz8E2pK4kN/d10PLcTClqoUrysr3koy2VHkyynxF44e9XUqYnjzjrQuYRqB8XfS73hjptFyFAmW3aUF+KVA0M+rUUI8h0NB/VsMIONFTRZ0Qz82jWlF6IIszA+Cwk/8v3UgLpYC3Tvi8a5Jy0AdLOuCjP4s6/TDdfDh58wXGfvLxzB0E9+wo0BYYRUHvgZfTSFm8zb9qYFg2CMqS+YTKvZSuZIbaLqEjMfWMHVbwZZApZM2/YtPvVSPUWowmD78zS590AKUUjMG3940G6+fLga9BpX16+g5l+dA6mO8aXayJVw+Q53Fnm9b7Jer7ormcFpiVI+27Ztdw1OTtriJcSMu7YmqOrZTxeHbGkEMXW0IjMQiqPeTYrO3XE1EC64pgC49urS6Recdw3Ly5Dpncg07O/gupijU81kfrIGsjeSN/IWDJwMyfzKEWmbKR9m6xsUXHhRhDxissTBoiFihEFhnHdQWuHTCP0MzfMKyawWclCsNHDQsqXoSJm4Av10sEg10m/Baucu3cvJ0yv3P5on9M7rG/XRIo6KbDEM9VG7NLYhj1brBaB0ibYyEHuQkykfpu4likYyym41rwtp1WjGMRXhqibsho7sud4gxigeuS2kt02wslqtVoalAGfiRTfjS0ZMKJIzrAz0Py2icVbEOikP/6T6KNfnnPczzciptHg+/xh9BmG6iEdoymGN4lOMVpjdqK89gZJjxwMw9TCl3L7eiykKp+2A1tZoDgcfRxI+A2TsJF6ePwTqAPQAFFS5sQE18WWqmjzHg7Za03tPNQKpIo0X417nKW3nKlCLLrsSfIFq49ErEv7GTHX7v6I2/+aIPrgXxz38MYNwDTpqH+PZ1uGaiFt4ZvOTF0zXA9mdumoOrjpima2bBbSCW7MijnJWEKtOeZAbsHjJYpEXcescEUSby/SQtxVxl7sTeXsHFuO1EbL2OS7+A3RLCyUa3iPsoKRgm/IifQ1ePGHmwTT+2WdtBbSFBAvEJfq4/0ZeZm3p328UHCz9gsDaUtARbh8fuWtdxEJZZ2W46PSlSWlqlTciXfTcnw81ihSYXnf4TMdtRSpEGTbo4MvTJkha0cI4jsBn3t9kEam/BMsYN5cvXkTQX3xt3i2ZSlFyvDD6GNZSqczYhmoitiUoDgJdTwoG5l5nIEUm6dul7LaCnCXS+cfa4YnS4r3ZYyn2kn6Ir4lV6EUonZJpmVIhQI2Db+thPkGtilSFTzOT5f29hBUuIA5v3f16lXM9Jzl3U1uBsceOZ1+Xtp4OFuTni/S1MDzq72gjSg+6tpuxuqlI+2jkV3hac9toYlW5FMWfVR+bl0VCTUR0U2bM7aBlTW1jash4RMqQSpPit8l5o38tTdFCqv41h5UDPUALGC+O713DzF98Q14lLKthhSpLRQkyXZ2TUJsgFtL5PWd028V26SZgCU60i4mQPd3drADkKhpNFaLhVpMR2USN7KBRYlh//fE9GHZSKnPq+JJqOD72BCpDmyP7/du3UJM4QLm1fXr9+6hjnqXuQWTaIOgT7DaJ/qbj4Zj2rgHZVGXslSkvV1EjGXYY+dVN30tXccUBkLsAyZG/RH2JjFjV1PDvgSpQPXaeKibmvk+vCFSGCkIt0gjqIDpl/sc99+nKdO3b0ptI24jpPac7O7I4nS7rEsPbQo9KlLkuxPnrAGlhSqbqJcRNoHyOy2YHmk6oRYgGsxRK52f2Ugp+xZQPvqmkq+PzZAOgEnz72vXIqiwoz4ABN9cu3b9OoL6A1fiZYhUH6kUZKoCbaCyRjFwdwgDuZalIbXQkMj2kWGHJFnV6Tom12xx/yXfQLjYnRQM8JgcEykjBsBC9SGKuXc2QgoXMK+iCPuEKVzAPIuRxkwfVnXS2mlOppH1GfTQxMTsWByHXDVk9dCQ4hWHwN45XCX4yEHWF6gWWMqfJ/xNelLnolyyPYnBMJFSJu5YyLTghdwbGyGF2/1wmL2OoIIFzL/24N8J059B1VdEadZCqtjGIrfG6aBhrPsBSy1k9JD9goa0h33ifebFEFKX8CBZqdMv85QatsVJ/olRLa7LahZPiSyk1FUwFB4y2rk3NkIKOunD06hLRkz3/gFm1lt7txDT6/deVXZSAqmIlKEpKq7dDr1CV8RbIaJUtJQToXZLupxoSPFyJOcFJYX9e+QGKXZ2ZGNRcSe1CfdJHxdcWqWsqAaElDlsY3fVbu6NTZBCy+uHKBEmhvoMEPwWrFEjpgDq6XfsbVKsFKlpJ8p4xtbhzCsG/xBPUEPktjkNqUPdUmZcyyWeKJ3ASN/XgLoHg4y1sqmUmP+Zm2usMApnC0hVMNi8gcNrwvTW9xz348EBmFJvRVBPT/erOymBVPPj9HOfCK7nmcFvC/ZudREDEfxLQzrcoHnwmWij1CVODLG4tWWmZvSqXZomi9eXLKQCyxrcBlKYj/gEhnrGUE+fAYKvL11KmX5fsk2aXqXo47WWGJdLCR6LNS1E37AlEv43GlJvI6SkeaLi4d/GU5yKGmnWaJog+6okWomDsUflSJmJXltAChcw370FC5UE6il07sJt06Sj3vof8HRl+d+xaG57Nd37kCdV1sDvijS9jdSt5CCk2YgwjLQ8mb0SKSskcQtIwQDwKkorTZgCgvtfxlH2B5GHECDWqidk6k5ML90ILbqoY02wvSJXSyhHimtDrHGtwwxSH30VjyfYUSlm3cWo3ZTFh3C/K1IYzvvzTcAUQX3IcT+h2AYA9eBrGE1efg0o+uaaL1YxRTXkBnUOdkm7Og0p2jYRw371pXJzCfb3tBPU2M+U647IBnPzcRYZYXS/A1LQSZ++vQGzEGOm/wYLGCKh/wAGII1r7Lky9ktb6YYafYsZYdg0lY2GtJXUl7je7FpQeHsF+VZTxlljHy9iWPFn8a1ULWLeHVIYY/G/d+9GmaUQ6pPzbADSpW9BV6uTss3aAtdSDzbVT91PkNKi7+uURyLV0UMbNRbjOVkhHmejyu6hEL98b0RDtLguW9fh9dRvjhQuYD55cTdmCjsqXMBkogTrLGCgmFENQ+zVFE3KAO6bjO/VLI/uEKx/mBMWhhCvGPGCKO/3Q8FKpQ5BIj74t0YKOun+ZzBlLWH6BLz2mowS/CkKSqohdqDKEG8BKrTcb4Qh7zKvWV5mJwYtcn9NQrKFIgsVuPVnYTdDYfTA7smSQvxKt/27QgrzEb95CUMAY6hvH8IFTBpuf+n1PmdNnWFBxXVySezRCnshFEpgB06SYU+AOuUZqEixfcSKlgE9WWcZBjigQO4TnhOhsH5DvgaxZHhPl2bvAmnZiA/InN+BmaUx1Bs/c5SkGEstaFRcp5YgJV0OxdSTDpps2dsnynw6zDsTqUhHqMLY4corM2AcOYqmALhzizc8KbkyfnUhrXSxvT2kI2wplNg2A/BoXz2/k0AFTJ+yP5uRxs5Roc2JVphGdXbzX9VReE8xgCqRIymuLbTnK3JsoAeqYBvHZDy2L8AjR9v8lGJ+L7GN28M9Qi46FNItN1YjJGOJt4iUYXGRgmc1PHoOj5qLmb74+ccvvsikmN6n6Jy+G14a9KmnAVZmYVMJn9/AOLQMhVgqu+RsS0fakXE4GbV9IByiQFlV4pWo6WE3JS1eGxtSyprKxerWCCfbHKmOs60pYWhI0LsLjw9EUA+gYQR3YE5hINnNGzdevHh55/nz52dnJ1g753QTuDyOt5e22wI4He1wi1QfWw/34nl1hGBqadqUbDciCNykGGoq/vIaN0Ba7ak41tGlZkJOyA2h7SFVsTurGLadfgh000+ex2dCAn0Y+Rbgnhrc94ZI716+DBOc8FkNOzsn/8cI560IzSbSgow8uCE2n6Ti7DRY4w6TGSsrQ7OlIlMV7w2Z1FVwYXNOlKkb/zh+hTfDQl2MlpmrbA9p6jvNZkVmjUd4YEB0KCSE+lm0bNlLkF6lI/2YtU6tirbvpIlBRn4ew11YbAfZJ1WHOAkzZxEzEyhwhdp8joemoDphHaEmZ7ftWR4iK3VzKkL2zGhrbGS3lraINPXayOn6SXcOM9UJg46ewtRRCPVZBinspXcLSOHJR3QffmUCBT5LpRhJ5ae4zfWkh3qXNfLmOImmbk5Mmg7KK2bg4zd1rZtmERkMAyO/lcMKcWsRiWv2eoiO2FB7w3m+o28RqUqkV4Sarur6qLNYy27WOoEHL3x1FkGNO2kGaaGXwrMaGEnD1TkxacKHmA/ZddLuIdryzBtrmuOtZmRgRH5MZicjEl3NFLorB1xruJryxLEKMisgYSBluin7tJZ0rojuOJx6YLG+6MrZSI4tIyUjQBRBDMO1GZ21mXXgwJMXHh1FSJ8VkRZ66ckjpnuwRprTJA1PknJj4gp7mIBcW5Yk2TbJEaxwLDM7ZVgTCC5KfK1MsL/Ndid3M6MmZQWDtBDID4JFlp3NGcZ/bhNpjyxUVFAbzbmxemB6/xye9fnDpepeevIV+AJjLVYnc22RupHEPFMhN41lVcgYLkvs75Qm9mdOQsirRc6molvieZuWxjnZs6qgz1+DlPOoYZiinL1PWOLR0dHjgxxSmnn06TlnscIz6iC1cOYY785zj+SUHNYgUlYkpcdvrEtCJYRFCSirS9xF2bkWcDnNbISiPLO2vxPDZSqQlJwrAy5kzo6eXKrupfC4uRYLWK2UYSKnq+AabPE2o45sm2LNlB6So88kxrXMfDZ5Tg7RD9rlm4qaxGg4Snti1Tkkh3EHJUjB0pk2OOS3FqDz9OPH6Z53AemVBOnJx2WpTvUS+/XUfrDzbiR1YtCgmsaU5pKtOsrKlYq9XjSNoCLCPE12LUnSQQ8TGJRYOKUd/WzKu0EKJq9imWY7Ny1BC/bph2jvBQJ9Ro67oJc+fvwYLWDY8Q3jXRT8XLrvOeBlFOZrFFyDg4kpkXaMKCqyPKX3lfFhclIc4wwqy1kKtpKZGQV+Ub2Z7xn4/qrDczozI5NkKYqu0Y0d4O3kKu0c0t3ktP9dFtIh+uYxo8wlWaYo2tK00Ezr7Ydy3D48k5L57gjnB5dHtfjpDp1XrDN9PFtLsum6rmnbkr3uDlk3h8tj/lyVOph0eUkCljO8ljuf1frNt5GHbo95QDghqxPMTclUYHKBYsryPEAhTfgps/WtJr+kOw1YM3oLV09ZmYId/XqrLIN1POUz1RGdSOWhq9vRqOUsgiBYrIb9uo2NrUFL8xbgWp72q49WrZLua9P5GiicOu+skEKZ/VUAxSqxp7XqaXzRA+kb/VYa1ETaEG3UqFGjRo0aNWrUqFGjRo0aNWrUqFGjRo0aNWrUqFGjRhRZmwdhbOuHcnXnN4qn+BNp7Cqu67JyaWKFxqZXXfyyyadb7OIHZICqM5sFQTBb1ohYGA3f36bg8NFvR5b/ntzGP28+KD+JPKepwcwTGJDJ/trKm7Un3qrG2Ua+8S5/UPuPLYdIS+x1VMdDXcDShr4ex3n68Wud3sDDgY1qH1OzfHQeQmuQ5KEM4kbQ8ntDDwFQx8MRFXXPXKAToEeaOvZQl+15q/5AyvLTdlFRflJUC34gaXRWx4nPefOHrtN/X6GSSB3BnfPHcY3qazk8XMe/9DSLju21wrAdCodxRfUPZzM5/tM/DKftGNU8WPwSnVmxis+vD+ZG6B7G1e23xXCXerrMZM7xSQy2djgX58fxIYatQ6HbXot5pElMaTeY/hL9LsIcxpAG0VNYXWlhRhHtU1lxC9m+74scyZZlKZ4snV2AM4ij/EMPHn4pRX8HUYVbS8BQ5aMo3B4kq0XB4xb8taNB/Hu4XSEJ+vfiX6FYtAHOMP42vHZLpKQq66bGaVLcPDT4a4hOdFiOpYDRWJ8rDKQzeRa/04U3NI0yLXww8apedCXffl/7KJxLhw5Q/LcM/unERzgdw6qbGCTSLswNXEVH5w/NseOsojNFO7vw+/FPzYVhYpQkSKeQoBOR96NWM6P84MiY71m9uKUAYiPYXuB1B8ew5/cFFlJ0TCmBVJ8vvSSC3JffY6Rh7u+WG3W4Y0hukUUKE6m8yJKZ8JCjA6tNM6I/o9E1RCnLCClsBNq8HKnihmHoCtEcGE2V+i7s6v4x/HdgsJCiM9yjuwrifCh9HB7GI3WDlPg7QTqbqpZmygykziE8uy5K8RgcR/ZJPFqjo3yLSDnDUy1Hiksj7dvOoQMsbidOsYmQjiKkVhsWN7EZSJeo9UC21jpCavnQBojOivFRBlPN38/8M8kxV95qtYqmwBipHCHVZ7ZodOPTkYLEPIqQRjlc6rrbGnTjdK5A1HpTO/rSHB2948VmUEAg9demaIYRUp9IArRmcQebRicFabCpjA6juxnvDv2pkDu6SztE4y3KENd2p+NunP+uS8NRX44sNZ2farCRjJSNF2D/8dJmUMuoHjTY8v3kN6msgTYYx7+M4cUT3QLOl+O4I+pdRUxSlNVg7c5iRgtkZI7jPuTBRtCZJp/zNX0aMR/MU6R6XDTnd+FrrWX0UoxRC/mgH2QH0BbKCpxge9aZr53hKrmIGSZLoM7chIXr8/cPKUueAxOhS85EJxPU6qTCTVtwOHzXFWxR/2wENWzb/OFs8xOdmZod8u5h6YkCjd6xemOHmeH6q+Q7TpNO1qhRo0aNGjVq9EfS/wNwi/NBhJ+MRQAAAABJRU5ErkJggg==' alt="pic" width={180}/>
            </Link>
          </div>
          <div>
            <div className="flex lg:hidden items-center gap-7">
              <Link to="/mycart">
                <div className="flex items-center ml-10 space-x-2">
                  <AiOutlineShoppingCart
                    size={31}
                    color="white"
                    className="p-2 bg-orange-500 rounded-full"
                  />
                  <div className="font-semibold">
                    <h1 className="text-xs font-semibold">MyQuestions</h1>
                    <p className="text-xs text-slate-400">
                      Question 1 : {cart.cartItems.length}
                    </p>
                  </div>
                </div>
              </Link>
              <AiOutlineMenu
                size={35}
                onClick={() => {
                  settoogle(true);
                }}
                color="white"
                className="lg:hidden cursor-pointer bg-[#121a37] p-1.5 hover:bg-orange-600 ease-in-out duration-300"
              />
            </div>
            <div className="hidden lg:block">
              <div className="flex items-center">
                {/* <Link to={`https://wa.me/${links?.Whatsapp}`}> */}
                <a
                  href={`whatsapp://send?phone=${links?.Whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <div className="flex items-end space-x-2">
                    <div className="">
                      <img
                        src={whatsapp}
                        alt="whatsapp"
                        className="w-10 h-10"
                      />
                    </div>
                    <div>
                      <p className="text-[#8d8d8d] font-semibold text-sm">
                        24/7 Services
                      </p>
                      <h1 className="text-lg font-semibold md:text-xl">
                        {links?.Whatsapp}
                      </h1>
                    </div>
                  </div>
                  {/* </Link> */}
                </a>
                <Link to="http://localhost:3002/sign-up">
                  <div className="flex items-center ml-10 space-x-2">
                    <AiOutlineShoppingCart
                      size={39}
                      color="white"
                      className="p-2 bg-orange-500 rounded-full"
                    />
                    <button >Login</button>
                    <div className="font-semibold">
                      <h1><a href="http://localhost:3002/sign-up">Signup</a></h1>
                      {/* <p className="text-slate-400 ">
                        {cart.cartItems.length}
                      </p> */}
                    </div>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Bar with drop down only for Big screens */}
        <div className="z-50 justify-center hidden px-24 mt-1 translate-y-6 lg:flex">
          <div className="flex items-center bg-[#121a37] p-4  rounded-l-md w-full">
            <ul className="flex items-center space-x-12 text-white">
              <Link to={"/"}>
                <li className="cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out">
                  PRODUCTS
                </li>
              </Link>
              <Link to={"/about"}>
                <li
                  className={`cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out ${
                    Page === "About" ? "text-orange-500" : null
                  } `}
                >
                  SOLUTIONS
                </li>
              </Link>
              <div>
                <li
                  onMouseEnter={() => {
                    setservice(!service);
                  }}
                  onMouseLeave={() => {
                    setservice(false);
                  }}
                  className="cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out"
                >
                  TEMPLATES
                </li>
                <div
                  onMouseEnter={() => setservice(true)}
                  onMouseLeave={() => setservice(false)}
                  className={`${service ? "flex" : "hidden"} pt-2 absolute`}
                >
                  <ul className="text-sm text-[#676767] w-[15vw] cursor-pointer">
                    <li
                      onMouseEnter={() => {
                        setnonmobilewhat(true);
                        setnonmobilewho(false);
                      }}
                      className={`cursor-pointer ${
                        Page === "whatwedo" ? "text-orange-500" : null
                      }  bg-white border py-1 px-3  hover:text-[#ff5e15] transition ease-in-out duration-300`}
                    >
                      POPULAR CATEGORIES
                    </li>
                    <div>
                      <li
                        onMouseEnter={() => {
                          setnonmobilewho(true);
                          setnonmobilewhat(false);
                        }}
                        onMouseLeave={() => {
                          setnonmobilewhat(false);
                        }}
                        className={`cursor-pointer ${
                          Page === "whoweserve" ? "text-orange-500" : null
                        }  bg-white border py-1 px-3  hover:text-[#ff5e15] transition ease-in-out duration-300`}
                      >
                        POPULAR TEMPLATES
                      </li>
                    </div>
                  </ul>
                  <div
                    onMouseEnter={() => {
                      setnonmobilewhat(true);
                      setnonmobilewho(false);
                    }}
                    onMouseLeave={() => {
                      setnonmobilewhat(false);
                    }}
                    className={`${
                      nonmobilewhat ? "flex" : "hidden"
                    } bg-white py-2 text-sm text-[#676767] w-[18vw]`}
                  >
                    <DropDown ismobile={false} type={"Whatwedo"} />
                  </div>
                  <div
                    onMouseEnter={() => {
                      setnonmobilewho(true);
                    }}
                    onMouseLeave={() => {
                      setnonmobilewho(false);
                    }}
                    className={`${
                      nonmobilewho ? "flex" : "hidden"
                    } bg-white py-2 text-sm text-[#676767] w-[18vw]`}
                  >
                    <DropDown ismobile={false} type={"WhoweServe"} />
                  </div>
                </div>
              </div>
              {/* services */}
              <Link to="/BlogPage">
                <li className="cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out">
                  PRICING
                </li>
              </Link>
              <Link to={"/shop"}>
                <li
                  className={`cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out ${
                    Page === "Shop" ? "text-orange-500 " : null
                  } `}
                >
                  RESOURCES
                </li>
              </Link>
              <Link to={"/career"}>
                <li
                  className={`cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out ${
                    Page === "career" ? "text-orange-500" : null
                  } `}
                >
                  BLOGS
                </li>
              </Link>
              <Link to={"/contact"}>
                <li className="cursor-pointer  hover:text-[#ff5e15] transition duration-300 ease-in-out">
                  CONTACT US
                </li>
              </Link>
            </ul>
          </div>
          <Link to="http://127.0.0.1:5500/src/components/Q1.html">
            <button className="bg-[#ff5e15] w-60 h-full relative overflow-hidden group text-[#fff] p-4 py-2 flex  cursor-pointer items-center space-x-1.5  rounded-r-md transition ease-in-out duration-500">
              <span className="absolute left-0 w-0 h-full transition-all duration-500 ease-in-out bg-orange-700 opacity-100 group-hover:w-full"></span>
              <span className="relative flex items-center">
                <AiOutlineWechat size={20} color="white" />
                <h1><a href="http://127.0.0.1:5500/src/components/Q1.html">Make a Free Trail</a></h1>
                <AiOutlineArrowRight size={20} color="white" />
              </span>
            </button>
          </Link>
        </div>
      </nav>
      {/* Mobile Navbar */}
      {toogle ? <MobileNavbar settoogle={settoogle} /> : null}
    </>
  );
}

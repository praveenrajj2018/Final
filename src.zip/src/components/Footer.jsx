import Particles from "react-particles";
import { loadSlim } from "tsparticles-slim";
import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { db } from "../Firebase";
import { doc, getDoc } from "firebase/firestore";
//import vvmain from "../images/home/footer/foot-logo.png";
import { img1 } from "../images/Bannerimages";

const Footer = () => {
  const particlesInit = useCallback(async (engine) => {
    await loadSlim(engine);
  }, []);

  const particlesLoaded = useCallback((container) => {
    // console.log(container);
  }, []);
  const currentYear = new Date().getFullYear();

  const [links, setlinks] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const documentRef = doc(db, "SOCIAL-MEDIA-URL", "LINKS");
        const documentSnapshot = await getDoc(documentRef);
        if (documentSnapshot.exists()) {
          setlinks(documentSnapshot.data());
        } else {
          setlinks(null); // Handle the case where the document doesn't exist
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="relative">
      <Particles
        id="particle"
        init={particlesInit}
        loaded={particlesLoaded}
        className="h-[80rem] md:h-[50rem] lg:h-[26rem]"
        options={{
          fullScreen: {
            enable: false,
          },
          background: {
            color: {
              value: "#0a1024",
            },
          },
          fpsLimit: 120,
          interactivity: {
            events: {
              onHover: {
                enable: true,
                mode: "repulse",
              },
              resize: true,
            },
            modes: {
              push: {
                quantity: 4,
              },
              repulse: {
                distance: 200,
                duration: 0.4,
              },
            },
          },
          particles: {
            color: {
              value: "#ffffff",
            },
            move: {
              direction: "none",
              enable: true,
              outModes: {
                default: "bounce",
              },
              random: false,
              speed: 1,
              straight: false,
            },
            number: {
              density: {
                enable: true,
                area: 800,
              },
              value: 80,
            },
            opacity: {
              value: 0.5,
            },
            shape: {
              type: "circle",
            },
            size: {
              value: { min: 1, max: 5 },
            },
          },
          detectRetina: true,
        }}
      />

      <div className="absolute   flex justify-center items-center top-0 w-[100%] text-[#d5d5d5] left-3 right-3">
        <div className=" pt-20 lg:flex space-y-14 lg:space-y-0 ">
          {/* //first section */}
          <div className="space-y-4 ">
            <img src={'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdIAAABsCAMAAADpCcO1AAABUFBMVEX///8nJVzgG1EPC1IlI1u1tcESDlO/v84AAEwWE1W4t8ciIFrs7PGZJH5HRnGpqbzk5Ora2uMDAE+0tMTR0dqPjqgAAEocGlf09PUZFlXe3uSTk6uyIW6lpbvXHFcfHVipInR0dJLAH2XSHVrJHmC6IGm9H2fVHFj+9vikI3erInO0IG3iIFnGHmKEg53oz+IAAEVsao2eI3sAAEFVVHw4NmtxcJDKytZiYYdSUHtCQG5/fprfAEYxL2OVDnjHAFfxytq5cqfv3uvTNHKrQ4ulMIOoTZPTpMSaBHLIN3bXss6dNom7PoLKlbzp0+TVMGiyYp6jC2+vB2f4ytbBZJm5Uo386u7kOmnCg7HsgJnoZ4avBmz73+fVkbLsg5zeAD/zscHlTnTeiafpnbPYXofzucjGQn3TUYCxAFvZe57DVov40tvworTJXo/Sp8cAADHNGX2sAAAXZUlEQVR4nO2d7X+bRrbHIVAkBBYISQZEZKI8OolDLFsSCEV2Nm26Th+Sm3TX7TZpd9Pe9GZv29v//92dAWYYYAZQrbTdht+LfBw9MDDfeThz5pwRxzVq1KhRo0aNGjX6A6gVTCMFE/X3vpVG25FmuJHssEH6J5Em8ZGUboP0T6IG6TuXVaUtl9cgfecaH7fZMmQ+nHmavsXyGqQl0uuq9CqoihkSRdeWhPl4a1TfP6RqC6lqxPO1VqeOWuN+2WUqkMZcFWk+3BKB9w/p4DAZ844rntgqBZXRsKx11EEKqUrzVu0Cy/QeIjWSOmxXPHGnvt3S00rerIkUMNgd1i6xRnkN0rysDsfdP7t9+8qVO3cuX75798aNm1evfnjv3vVnz65du7V3gPXhfWAClcyEtZHyvDTdwgM2SFkCHW//o9sAaUoU8Lx+eu3atb29g0upHn8MJmin5EL1kYr24uIP2CBlaDTguL+eEUhvgk4KmV6HfZRg+mTn5BNQjyPmlVKkrlmUq4gkVGN84QdskDIEOun546MjhPRGNO5CpNeySA8+3dnZAZ9nT4MYqTidFLQIloZgplRFY3DRB2yQ0uWDyfEvZ0fZgZeG9DNA9ORzjmsxUaAqFvke7W1L7U9FFzM1LzydNkjpAguYpydH1b30GeykOzuPOM5hGcgVSKF6Mxsztf2LPV+DlC7ohvivk6PqXno7InryF9CvWavKGkg5zkN3dfFu2iClyQJ47p/sVCN9shPr5D67m9ZCynkymk3FC5JokNLUgQuYnWqkB48TpDtgIaMz/A31kFrI8hXtCzqRGqQUjUDdf35SA+mToyPUTT9hdtN6SLkxMoxl5jrGGnTGjuOMO6VWcT2ken/srCYrz9FK7+qCGrX6mtbxf+2WBLxJbzIZjjulrTNFynT4Advo0c7JycnZ2dlzoJcvX7x48fbt26v3rp+enkKggOYDoD2wykFQP93nLDqLmkhH66SbmnR3w2C8bBuCDCUY7ZlWaWGXIPU9pS3Itm2atiy05Umr8MneB0hlY4aFP/VBkdpg3G2324IkgdttL8f4fge9WAOVfq2+hW7STW9yd+3ka8/qo284yLiUtQ9I9XGZPijr/D6hhzl9kehvt29jpidPQTelPndNpNxMSVAsi++p/aUiK3wqV1ZmDNO4CqnqhKZN+jdEU1o7uc/2DCGRwXaicD76VNvI9Q+r383cMLjfUIvLQKORlJ2o9OPkWodRgf7SlMmbBFcLsq1YxbeYLhdkgVR7hT5bdy67fwWMywnUyOalI6uLNEgWp8q88FYnFNyMkwlezpUX1AtWIO3PBYXPSxG6uX2nhYlqqcTXOUUfsnMf6ncFJX/DijCPhjFDjCXkkLaTz8E2pK4kN/d10PLcTClqoUrysr3koy2VHkyynxF44e9XUqYnjzjrQuYRqB8XfS73hjptFyFAmW3aUF+KVA0M+rUUI8h0NB/VsMIONFTRZ0Qz82jWlF6IIszA+Cwk/8v3UgLpYC3Tvi8a5Jy0AdLOuCjP4s6/TDdfDh58wXGfvLxzB0E9+wo0BYYRUHvgZfTSFm8zb9qYFg2CMqS+YTKvZSuZIbaLqEjMfWMHVbwZZApZM2/YtPvVSPUWowmD78zS590AKUUjMG3940G6+fLga9BpX16+g5l+dA6mO8aXayJVw+Q53Fnm9b7Jer7ormcFpiVI+27Ztdw1OTtriJcSMu7YmqOrZTxeHbGkEMXW0IjMQiqPeTYrO3XE1EC64pgC49urS6Recdw3Ly5Dpncg07O/gupijU81kfrIGsjeSN/IWDJwMyfzKEWmbKR9m6xsUXHhRhDxissTBoiFihEFhnHdQWuHTCP0MzfMKyawWclCsNHDQsqXoSJm4Av10sEg10m/Baucu3cvJ0yv3P5on9M7rG/XRIo6KbDEM9VG7NLYhj1brBaB0ibYyEHuQkykfpu4likYyym41rwtp1WjGMRXhqibsho7sud4gxigeuS2kt02wslqtVoalAGfiRTfjS0ZMKJIzrAz0Py2icVbEOikP/6T6KNfnnPczzciptHg+/xh9BmG6iEdoymGN4lOMVpjdqK89gZJjxwMw9TCl3L7eiykKp+2A1tZoDgcfRxI+A2TsJF6ePwTqAPQAFFS5sQE18WWqmjzHg7Za03tPNQKpIo0X417nKW3nKlCLLrsSfIFq49ErEv7GTHX7v6I2/+aIPrgXxz38MYNwDTpqH+PZ1uGaiFt4ZvOTF0zXA9mdumoOrjpima2bBbSCW7MijnJWEKtOeZAbsHjJYpEXcescEUSby/SQtxVxl7sTeXsHFuO1EbL2OS7+A3RLCyUa3iPsoKRgm/IifQ1ePGHmwTT+2WdtBbSFBAvEJfq4/0ZeZm3p328UHCz9gsDaUtARbh8fuWtdxEJZZ2W46PSlSWlqlTciXfTcnw81ihSYXnf4TMdtRSpEGTbo4MvTJkha0cI4jsBn3t9kEam/BMsYN5cvXkTQX3xt3i2ZSlFyvDD6GNZSqczYhmoitiUoDgJdTwoG5l5nIEUm6dul7LaCnCXS+cfa4YnS4r3ZYyn2kn6Ir4lV6EUonZJpmVIhQI2Db+thPkGtilSFTzOT5f29hBUuIA5v3f16lXM9Jzl3U1uBsceOZ1+Xtp4OFuTni/S1MDzq72gjSg+6tpuxuqlI+2jkV3hac9toYlW5FMWfVR+bl0VCTUR0U2bM7aBlTW1jash4RMqQSpPit8l5o38tTdFCqv41h5UDPUALGC+O713DzF98Q14lLKthhSpLRQkyXZ2TUJsgFtL5PWd028V26SZgCU60i4mQPd3drADkKhpNFaLhVpMR2USN7KBRYlh//fE9GHZSKnPq+JJqOD72BCpDmyP7/du3UJM4QLm1fXr9+6hjnqXuQWTaIOgT7DaJ/qbj4Zj2rgHZVGXslSkvV1EjGXYY+dVN30tXccUBkLsAyZG/RH2JjFjV1PDvgSpQPXaeKibmvk+vCFSGCkIt0gjqIDpl/sc99+nKdO3b0ptI24jpPac7O7I4nS7rEsPbQo9KlLkuxPnrAGlhSqbqJcRNoHyOy2YHmk6oRYgGsxRK52f2Ugp+xZQPvqmkq+PzZAOgEnz72vXIqiwoz4ABN9cu3b9OoL6A1fiZYhUH6kUZKoCbaCyRjFwdwgDuZalIbXQkMj2kWGHJFnV6Tom12xx/yXfQLjYnRQM8JgcEykjBsBC9SGKuXc2QgoXMK+iCPuEKVzAPIuRxkwfVnXS2mlOppH1GfTQxMTsWByHXDVk9dCQ4hWHwN45XCX4yEHWF6gWWMqfJ/xNelLnolyyPYnBMJFSJu5YyLTghdwbGyGF2/1wmL2OoIIFzL/24N8J059B1VdEadZCqtjGIrfG6aBhrPsBSy1k9JD9goa0h33ifebFEFKX8CBZqdMv85QatsVJ/olRLa7LahZPiSyk1FUwFB4y2rk3NkIKOunD06hLRkz3/gFm1lt7txDT6/deVXZSAqmIlKEpKq7dDr1CV8RbIaJUtJQToXZLupxoSPFyJOcFJYX9e+QGKXZ2ZGNRcSe1CfdJHxdcWqWsqAaElDlsY3fVbu6NTZBCy+uHKBEmhvoMEPwWrFEjpgDq6XfsbVKsFKlpJ8p4xtbhzCsG/xBPUEPktjkNqUPdUmZcyyWeKJ3ASN/XgLoHg4y1sqmUmP+Zm2usMApnC0hVMNi8gcNrwvTW9xz348EBmFJvRVBPT/erOymBVPPj9HOfCK7nmcFvC/ZudREDEfxLQzrcoHnwmWij1CVODLG4tWWmZvSqXZomi9eXLKQCyxrcBlKYj/gEhnrGUE+fAYKvL11KmX5fsk2aXqXo47WWGJdLCR6LNS1E37AlEv43GlJvI6SkeaLi4d/GU5yKGmnWaJog+6okWomDsUflSJmJXltAChcw370FC5UE6il07sJt06Sj3vof8HRl+d+xaG57Nd37kCdV1sDvijS9jdSt5CCk2YgwjLQ8mb0SKSskcQtIwQDwKkorTZgCgvtfxlH2B5GHECDWqidk6k5ML90ILbqoY02wvSJXSyhHimtDrHGtwwxSH30VjyfYUSlm3cWo3ZTFh3C/K1IYzvvzTcAUQX3IcT+h2AYA9eBrGE1efg0o+uaaL1YxRTXkBnUOdkm7Og0p2jYRw371pXJzCfb3tBPU2M+U647IBnPzcRYZYXS/A1LQSZ++vQGzEGOm/wYLGCKh/wAGII1r7Lky9ktb6YYafYsZYdg0lY2GtJXUl7je7FpQeHsF+VZTxlljHy9iWPFn8a1ULWLeHVIYY/G/d+9GmaUQ6pPzbADSpW9BV6uTss3aAtdSDzbVT91PkNKi7+uURyLV0UMbNRbjOVkhHmejyu6hEL98b0RDtLguW9fh9dRvjhQuYD55cTdmCjsqXMBkogTrLGCgmFENQ+zVFE3KAO6bjO/VLI/uEKx/mBMWhhCvGPGCKO/3Q8FKpQ5BIj74t0YKOun+ZzBlLWH6BLz2mowS/CkKSqohdqDKEG8BKrTcb4Qh7zKvWV5mJwYtcn9NQrKFIgsVuPVnYTdDYfTA7smSQvxKt/27QgrzEb95CUMAY6hvH8IFTBpuf+n1PmdNnWFBxXVySezRCnshFEpgB06SYU+AOuUZqEixfcSKlgE9WWcZBjigQO4TnhOhsH5DvgaxZHhPl2bvAmnZiA/InN+BmaUx1Bs/c5SkGEstaFRcp5YgJV0OxdSTDpps2dsnynw6zDsTqUhHqMLY4corM2AcOYqmALhzizc8KbkyfnUhrXSxvT2kI2wplNg2A/BoXz2/k0AFTJ+yP5uRxs5Roc2JVphGdXbzX9VReE8xgCqRIymuLbTnK3JsoAeqYBvHZDy2L8AjR9v8lGJ+L7GN28M9Qi46FNItN1YjJGOJt4iUYXGRgmc1PHoOj5qLmb74+ccvvsikmN6n6Jy+G14a9KmnAVZmYVMJn9/AOLQMhVgqu+RsS0fakXE4GbV9IByiQFlV4pWo6WE3JS1eGxtSyprKxerWCCfbHKmOs60pYWhI0LsLjw9EUA+gYQR3YE5hINnNGzdevHh55/nz52dnJ1g753QTuDyOt5e22wI4He1wi1QfWw/34nl1hGBqadqUbDciCNykGGoq/vIaN0Ba7ak41tGlZkJOyA2h7SFVsTurGLadfgh000+ex2dCAn0Y+Rbgnhrc94ZI716+DBOc8FkNOzsn/8cI560IzSbSgow8uCE2n6Ti7DRY4w6TGSsrQ7OlIlMV7w2Z1FVwYXNOlKkb/zh+hTfDQl2MlpmrbA9p6jvNZkVmjUd4YEB0KCSE+lm0bNlLkF6lI/2YtU6tirbvpIlBRn4ew11YbAfZJ1WHOAkzZxEzEyhwhdp8joemoDphHaEmZ7ftWR4iK3VzKkL2zGhrbGS3lraINPXayOn6SXcOM9UJg46ewtRRCPVZBinspXcLSOHJR3QffmUCBT5LpRhJ5ae4zfWkh3qXNfLmOImmbk5Mmg7KK2bg4zd1rZtmERkMAyO/lcMKcWsRiWv2eoiO2FB7w3m+o28RqUqkV4Sarur6qLNYy27WOoEHL3x1FkGNO2kGaaGXwrMaGEnD1TkxacKHmA/ZddLuIdryzBtrmuOtZmRgRH5MZicjEl3NFLorB1xruJryxLEKMisgYSBluin7tJZ0rojuOJx6YLG+6MrZSI4tIyUjQBRBDMO1GZ21mXXgwJMXHh1FSJ8VkRZ66ckjpnuwRprTJA1PknJj4gp7mIBcW5Yk2TbJEaxwLDM7ZVgTCC5KfK1MsL/Ndid3M6MmZQWDtBDID4JFlp3NGcZ/bhNpjyxUVFAbzbmxemB6/xye9fnDpepeevIV+AJjLVYnc22RupHEPFMhN41lVcgYLkvs75Qm9mdOQsirRc6molvieZuWxjnZs6qgz1+DlPOoYZiinL1PWOLR0dHjgxxSmnn06TlnscIz6iC1cOYY785zj+SUHNYgUlYkpcdvrEtCJYRFCSirS9xF2bkWcDnNbISiPLO2vxPDZSqQlJwrAy5kzo6eXKrupfC4uRYLWK2UYSKnq+AabPE2o45sm2LNlB6So88kxrXMfDZ5Tg7RD9rlm4qaxGg4Snti1Tkkh3EHJUjB0pk2OOS3FqDz9OPH6Z53AemVBOnJx2WpTvUS+/XUfrDzbiR1YtCgmsaU5pKtOsrKlYq9XjSNoCLCPE12LUnSQQ8TGJRYOKUd/WzKu0EKJq9imWY7Ny1BC/bph2jvBQJ9Ro67oJc+fvwYLWDY8Q3jXRT8XLrvOeBlFOZrFFyDg4kpkXaMKCqyPKX3lfFhclIc4wwqy1kKtpKZGQV+Ub2Z7xn4/qrDczozI5NkKYqu0Y0d4O3kKu0c0t3ktP9dFtIh+uYxo8wlWaYo2tK00Ezr7Ydy3D48k5L57gjnB5dHtfjpDp1XrDN9PFtLsum6rmnbkr3uDlk3h8tj/lyVOph0eUkCljO8ljuf1frNt5GHbo95QDghqxPMTclUYHKBYsryPEAhTfgps/WtJr+kOw1YM3oLV09ZmYId/XqrLIN1POUz1RGdSOWhq9vRqOUsgiBYrIb9uo2NrUFL8xbgWp72q49WrZLua9P5GiicOu+skEKZ/VUAxSqxp7XqaXzRA+kb/VYa1ETaEG3UqFGjRo0aNWrUqFGjRo0aNWrUqFGjRo0aNWrUqFGjRhRZmwdhbOuHcnXnN4qn+BNp7Cqu67JyaWKFxqZXXfyyyadb7OIHZICqM5sFQTBb1ohYGA3f36bg8NFvR5b/ntzGP28+KD+JPKepwcwTGJDJ/trKm7Un3qrG2Ua+8S5/UPuPLYdIS+x1VMdDXcDShr4ex3n68Wud3sDDgY1qH1OzfHQeQmuQ5KEM4kbQ8ntDDwFQx8MRFXXPXKAToEeaOvZQl+15q/5AyvLTdlFRflJUC34gaXRWx4nPefOHrtN/X6GSSB3BnfPHcY3qazk8XMe/9DSLju21wrAdCodxRfUPZzM5/tM/DKftGNU8WPwSnVmxis+vD+ZG6B7G1e23xXCXerrMZM7xSQy2djgX58fxIYatQ6HbXot5pElMaTeY/hL9LsIcxpAG0VNYXWlhRhHtU1lxC9m+74scyZZlKZ4snV2AM4ij/EMPHn4pRX8HUYVbS8BQ5aMo3B4kq0XB4xb8taNB/Hu4XSEJ+vfiX6FYtAHOMP42vHZLpKQq66bGaVLcPDT4a4hOdFiOpYDRWJ8rDKQzeRa/04U3NI0yLXww8apedCXffl/7KJxLhw5Q/LcM/unERzgdw6qbGCTSLswNXEVH5w/NseOsojNFO7vw+/FPzYVhYpQkSKeQoBOR96NWM6P84MiY71m9uKUAYiPYXuB1B8ew5/cFFlJ0TCmBVJ8vvSSC3JffY6Rh7u+WG3W4Y0hukUUKE6m8yJKZ8JCjA6tNM6I/o9E1RCnLCClsBNq8HKnihmHoCtEcGE2V+i7s6v4x/HdgsJCiM9yjuwrifCh9HB7GI3WDlPg7QTqbqpZmygykziE8uy5K8RgcR/ZJPFqjo3yLSDnDUy1Hiksj7dvOoQMsbidOsYmQjiKkVhsWN7EZSJeo9UC21jpCavnQBojOivFRBlPN38/8M8kxV95qtYqmwBipHCHVZ7ZodOPTkYLEPIqQRjlc6rrbGnTjdK5A1HpTO/rSHB2948VmUEAg9demaIYRUp9IArRmcQebRicFabCpjA6juxnvDv2pkDu6SztE4y3KENd2p+NunP+uS8NRX44sNZ2farCRjJSNF2D/8dJmUMuoHjTY8v3kN6msgTYYx7+M4cUT3QLOl+O4I+pdRUxSlNVg7c5iRgtkZI7jPuTBRtCZJp/zNX0aMR/MU6R6XDTnd+FrrWX0UoxRC/mgH2QH0BbKCpxge9aZr53hKrmIGSZLoM7chIXr8/cPKUueAxOhS85EJxPU6qTCTVtwOHzXFWxR/2wENWzb/OFs8xOdmZod8u5h6YkCjd6xemOHmeH6q+Q7TpNO1qhRo0aNGjVq9EfS/wNwi/NBhJ+MRQAAAABJRU5ErkJggg=='}width={240} alt="pic" />

            <p className="max-w-sm leading-8">
            Know your customers' thoughts in a flash. Create smart online polls, and have them launched in minutes, with RelevantZ Survey.
            </p>
          </div>
          {/* second section  */}
          <div className="space-y-8 md:flex md:justify-between md:space-y-0 md:space-x-20 ">
            <div className="space-y-4 ">
              <h1 className="text-lg font-semibold text-white">ABOUT US</h1>
              <ul className="text-[17px] cursor-pointer">
                <Link to="/about">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    About Us
                  </li>
                </Link>
                <Link
                  to={`/whatwedo/Warehouse-Management-(2PL-&-3PL)`}
                  state={{
                    image: 'https://www.zoho.com/sites/zweb/images/survey/freeonlinesurvey.png',
                    Tittle: "Relevantz Management",
                    Para: "Give an efficiency boost to your inventory management",
                  }}
                >
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out ">
                    What we do
                  </li>
                </Link>
                <Link
                  to="/whoweserve/Fast-Moving-Consumer-Goods-(FMCG)"
                  state={{
                    image: 'https://www.zoho.com/sites/zweb/images/survey/online-poll-creator-iphone.jpg',
                    Tittle: "Fast Moving Consumer Goods (FMCG)",
                    Para: "Relaxes our clients to get the goods delivered at their demanded place",
                  }}
                >
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Who we serve
                  </li>
                </Link>
                <Link to="/BlogPage">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Our Blog
                  </li>
                </Link>
              </ul>
            </div>
            <div className="space-y-4 ">
              <h1 className="text-lg font-semibold text-white">SUPPORT</h1>
              <ul className="space-y-4  text-[17px] cursor-pointer md:w-36">
                <Link to="/contact">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Request a Quote
                  </li>
                </Link>
                <Link to="/contact">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Contact Us
                  </li>
                </Link>
                <Link to="/about">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    FAQ's
                  </li>
                </Link>
                <Link to="/career">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Careers
                  </li>
                </Link>
              </ul>
            </div>
            <div className="space-y-4 ">
              <h1 className="text-lg font-semibold text-white">LINKS</h1>
              <ul className="space-y-4  text-[17px] cursor-pointer">
                <Link to="/shop">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Shop
                  </li>
                </Link>
                <Link to="/BlogPage">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    News
                  </li>
                </Link>
                <Link to="/BlogPage">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Gallery
                  </li>
                </Link>
                <Link to="/BlogPage">
                  <li className="my-4 hover:text-[#ff5e15] transition duration-700 hover:translate-x-3  ease-in-out">
                    Case Studies
                  </li>
                </Link>
              </ul>
            </div>
          </div>
          {/* third section  */}
          <div className="space-y-10 lg:px-10">
            <div>
              <p className="text-white">Call Us</p>
              <a href={`tel:${links?.Phone}`}>
                <p className="text-[#ff5e15] text-2xl font-bold cursor-pointer">
                  {'91+987654321'}
                </p>
              </a>
            </div>
            <div>
              <p className="text-white">Mail Us</p>
              <a href={`mailto:${'praveenrajj2018@gmail.com'}`}>
                <p className="text-[#1065cd] text-2xl font-bold cursor-pointer">
                  {'relevantz@gmail.com'}
                </p>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="justify-center items-center flex w-full bg-[#070b1b] py-6">
        <h1 className="text-center text-[#777777]">
          ©{" "}
          <span className="text-white hover:text-[#ff5e15] cursor-pointer transition duration-300 ease-in-out">
            Relevantz,Virdhunagar.
          </span>{" "}
          {currentYear}. All Rights Reserved
        </h1>
      </div>
    </div>
  );
};

export default Footer;
